# -------------------------------------------------#
# Title: Pickling
# Dev:   Tom Cooney
# Date:  Februray 23, 2019
# ChangeLog: (Who, When, What)
#   Tom Cooney, 2/23/2019, Added code to complete assignment 7
# -------------------------------------------------#
#Take a list and convert it to a binary string (pickling).
#Import the pickle module from Python.
import pickle
#Open a file to write binary strings to.
file = open("Pickling07.pickle.txt", "wb")
#Create a dictionary of strings.
person = {"first_name": "Tom", "last_name" : "Cooney"}
#Add the data to the open file as a binary string.
pickle.dump(person, file)
#Close the file.
file.close()
#Open the file again to read the binary strings.
file = open ("Pickling07.pickle.txt", "rb")
#Load the file with the binary strings.
person = pickle.load(file)
#Print the dictionary strings in the console.
print(person)


