# -------------------------------------------------#
# Title: Exception Handling
# Dev:   Tom Cooney
# Date:  Februray 23, 2019
# ChangeLog: (Who, When, What)
#   Tom Cooney, 2/23/2019, Added code to complete assignment 7
# -------------------------------------------------#
#Ask the user to input a dividend and a divisor.
x=input ("Type a number to be divided (dividend): ")
y=input ("Type a number to divide by (divisor): ")
#Divide two integer numbers. Handle the exception for zero divisor.
try:
    z= int(x) / int(y)
except ZeroDivisionError as e:
    print ('Cannot divide by zero.')
    z= None
#Handle the exception for string instead of integer entry.
except ValueError as e:
    print ('Value error exception. Value cannot be a letter (string). It must be a number (integer).')
    z= None
#Print the quotient of a non-zero divided and a non-zero divisor.
print ("The answer (quotient) is:  ", z)