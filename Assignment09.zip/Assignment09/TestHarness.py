import DataProcessor, Persons, Customers

print("\n Test the Customer.CustomerList class")
objEL = Customers.CustomerList()
try:
    print("Trying the wrong object type")
    objEL.AddCustomer(objP)
except:
    print("This should fail")

try:
    objEL.AddCustomer(objE)
    print("Trying the correct object type")
    print(objEL.ToString())
except:
    print("This should work")


