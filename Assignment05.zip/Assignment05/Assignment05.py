# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Tom Cooney
# Date:  Februray 11, 2019
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Tom Cooney, 2/11/2019, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dictRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

objFileName = "C:\_PythonClass\Assignment05\Todo.txt"
strData = ""
dictRow = {}
lstTable = []
# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load data you have
# in a text file called ToDo.txt into a python Dictionary.
objFile = open(objFileName,"r")
for line in objFile:
    strData = line.split(",")
    dictRow = {"ToDo": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dictRow)
objFile.close()

# Step 2
# Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options:
    1) Show current data.
    2) Add a new item.
    3) Remove an existing item.
    4) Save data to file.
    5) Exit the program
    """)
    strChoice = str(input("Which option do you want? Choose from 1 to 4: "))
    print()
# Step 3
# Display all todo items to user
    if (strChoice.strip() == '1'):
        print("Current ToDo Items:")
        for row in lstTable:
            print(row["ToDo"] + "(" + row["Priority"] + ")")
        print()
# Step 4
# Add a new item to the list/table
    elif(strChoice.strip() == '2'):
        strTask = str(input("Enter the ToDo item: ")).strip()
        strPriority = str(input("Enter the ToDo item priority. Enter either 'high' or 'low'... ")).strip()
        dictRow = {"ToDo":strTask,"Priority":strPriority}
        lstTable.append(dictRow)
        print("Current ToDo Items:")
        for dictRow in lstTable:
            print(dictRow)

# Step 5
# Remove a new item from the list/table
    elif(strChoice == '3'):
        strKeyToRemove = input("Which ToDo do you want to remove?... ")
        blnItemRemoved = False
        intRowNumber = 0
        while(intRowNumber < len(lstTable)):
            if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])):
                del lstTable[intRowNumber]
                blnItemRemoved = True
            intRowNumber += 1
        if(blnItemRemoved == True):
            print("The ToDo was removed.")
        else:
            print("The ToDo could not be found.")
        print("Current ToDo Items:")
        for row in lstTable:
            print(row["ToDo"] + "(" + row["Priority"] + ")")
        print()
        continue
# Step 6
# Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        print("Current ToDo Items:")
        for row in lstTable:
            print(row["ToDo"] + "(" + row["Priority"] + ")")
        print("")
        if ("y" == str(input("Save these ToDo items to file? Enter either 'y' or 'n': ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dictRow in lstTable:
                objFile.write(dictRow["ToDo"] + "," + dictRow["Priority"] + "\n")
            objFile.close()
            input("ToDo items saved to file. Press ENTER to return to Menu of Options.")
        else:
            input("New ToDo items weren't saved.Press ENTER to return to Menu of Options.")
        continue
# Step 7
# Exit program
    elif (strChoice == '5'):
        break





